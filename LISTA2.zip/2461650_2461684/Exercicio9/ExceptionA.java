/*
Exercicio 9
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio9;

class ExceptionA extends Exception {
    public ExceptionA(String message) {
        super(message);
    }
}