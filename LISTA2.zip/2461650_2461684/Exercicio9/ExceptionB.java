/*
Exercicio 9
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio9;

class ExceptionB extends ExceptionA {
    public ExceptionB(String message) {
        super(message);
    }
}