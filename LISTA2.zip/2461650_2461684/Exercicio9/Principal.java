/*
Exercicio 9
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio9;

import java.io.IOException;

public class Principal {
    public static void main(String[] args) {
        try {
            throw new ExceptionA("Excecao: ExceptionA");
        } catch (Exception exception) {
            System.out.println("Capturada Exception: " + exception.getMessage());
        }

        try {
            throw new ExceptionB("Excecao: ExceptionB");
        } catch (Exception exception) {
            System.out.println("Capturada Exception: " + exception.getMessage());
        }

        try {
            String str = null;
            str.length();
        } catch (Exception exception) {
            System.out.println("Capturada Exception: " + exception.getMessage());
        }

        try {
            throw new IOException("IOException");
        } catch (Exception exception) {
            System.out.println("Capturada Exception: " + exception.getMessage());
        }
    }
}