/*
Exercicio 2
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio2;

public class Veiculo implements IVeiculo 
{	
	private String nome;
	
	public Veiculo() {
	}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}


		public void emitirPassagem() {
		}

		public void calcularPagamento(double distancia) {			
		}

		public void calcularTempoViagem(double x1, double x2, double y1, double y2) {
		}
}