/*
Exercicio 2
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio2;

import java.util.List;
import java.util.ArrayList;

public class Principal 
{	
	EmpresaViagem empresaViagem = new EmpresaViagem();	
	
	public Principal() 
	{	
		ArrayList<Veiculo> lista = new ArrayList<Veiculo>();

		Barco barco=new Barco();
		barco.setQtdeCadeiras(30);
		barco.setQtdeMesas(6);
		
		
		Onibus onibus=new Onibus();
		onibus.setQtdePassageiros(40);
		onibus.setTipo("Circular");

		lista.add(barco);
		barco=(Barco)lista.get(0);

		lista.add(onibus);
		onibus=(Onibus)lista.get(1);
		
        System.out.println("Barco:");
		System.out.println("Cadeiras: " + barco.getQtdeCadeiras());
		System.out.println("Mesas: " + barco.getQtdeMesas());
        
		System.out.println("Onibus:");		
		System.out.println("Passageiros: " + onibus.getQtdePassageiros());
		System.out.println("Tipo de Onibus: " + onibus.getTipo());
		
		barco.emitirPassagem();
		barco.calcularPagamento(20);
		barco.calcularTempoViagem(1,4,2,3);
		
		System.out.println("Taxa para o barco: " + barco.taxa);
		System.out.println("Preço total da passagem: " + barco.pagamento);
		System.out.println("Tempo de viagem de barco: " + barco.tempoViagem);

		onibus.emitirPassagem();
		onibus.calcularPagamento(40);
		onibus.calcularTempoViagem(1,8,2,8);
	
		System.out.println("Taxa para o onibus: " + onibus.taxa);
		System.out.println("Preço total da passagem: " + onibus.pagamento);
		System.out.println("Tempo de viagem de onibus: " + onibus.tempoViagem);
	}
	
	public static void main(String []args) {
		new Principal();
	}
}
