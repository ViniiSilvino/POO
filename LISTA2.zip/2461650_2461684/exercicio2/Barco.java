/*
Exercicio 2
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio2;

public class Barco extends Veiculo{
	protected Integer qtdeCadeiras;
	protected Integer qtdeMesas;
	public double taxa;
	public double pagamento;
	public double distancia;
	public double tempoViagem;

	public Barco() {	
	}
	
	public void emitirPassagem()
	{
		taxa =    2000;
	}
	
	public void calcularPagamento(double distancia)
	{
		pagamento = 200*distancia + taxa;
	}
	
	public void calcularTempoViagem(double x1, double y1, double x2, double y2)
	{
		distancia = Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));	//raiz((x1-x2)² + (y1-y2)²)
		tempoViagem = 20*distancia;
	}
	
	public Integer getQtdeCadeiras() 
	{
		return qtdeCadeiras;
	}

	public void setQtdeCadeiras(Integer qtdeCadeiras) 
	{
		this.qtdeCadeiras = qtdeCadeiras;
	}

	public Integer getQtdeMesas() 
	{
		return qtdeMesas;
	}

	public void setQtdeMesas(Integer qtdeMesas) 
	{
		this.qtdeMesas = qtdeMesas;
	}	
}