/*
Exercicio 1
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio1;

public class Veiculo implements IVeiculo 
{	
	private String nome;
	
	public Veiculo() {
	}
		public void emitirPassagem(){
			return;
		}
		
		public void calcularPagamento(){
			return;
		}
		
		public void calcularTempoViagem(){
			return;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}
}
