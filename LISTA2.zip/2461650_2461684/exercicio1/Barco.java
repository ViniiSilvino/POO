/*
Exercicio 1
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio1;

class Barco extends Veiculo 
{
	protected Integer qtdeCadeiras;
    protected Integer qtdeMesas;
	public double taxa;
	public double pagamento;
	public double distanciaCartesiana;
	public double tempoViagem;
	
    public Barco(){
    }
    	
	public Integer getQtdeCadeiras() {
		return qtdeCadeiras;
	}

	public Integer getQtdeMesas() {
		return qtdeMesas;
	}

	public void setQtdeCadeiras(Integer qtdeCadeiras) {
		this.qtdeCadeiras = qtdeCadeiras;
	}


	public void setQtdeMesas(Integer qtdeMesas) {
		this.qtdeMesas = qtdeMesas;
	}	  
}