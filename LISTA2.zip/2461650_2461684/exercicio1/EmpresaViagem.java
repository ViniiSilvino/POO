/*
Exercicio 1
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio1;

public class EmpresaViagem 
{
    private String nome;
    private String proprietario;
    private String endereco;
    private float vendasMensais;
    private int qtdeMaxPassagens;
	private Integer qtdeFuncionarios;
    private Onibus onibus = new Onibus();
    private Barco barco = new Barco();

    public EmpresaViagem() {
    }
    
    //getters
    public String getNome() {
    	return nome;
    }
    
    public String getProprietario() {
    	return proprietario;
    }
    public String getEndereco() {
    	return endereco;
    }
    
    public Float getVendasMensais() {
    	return vendasMensais;
    }
    
    public Integer getQtdeMaxPassagens() {
    	return qtdeMaxPassagens;
    } 

    public Integer getQtdeFuncionarios() {
    	return qtdeFuncionarios;
    }
    
    public Onibus getOnibus() {
    	return onibus;
    }
    
    public Barco getBarco() {
    	return barco;
    }
    
    //setters
    public void setNome(String nome) {
    	this.nome = nome;
    }
    
    public void setProprietario(String proprietario) {
    	this.proprietario = proprietario;
    }
    public void setEndereco(String endereco	) {
    	this.endereco = endereco;
    }
    
    public void setVendasMensais(Float vendasMensais) {
    	this.vendasMensais = vendasMensais;
    }
    
    public void setQtdeMaxPassagens(Integer qtdeMaxPassagens) {
    	this.qtdeMaxPassagens = qtdeMaxPassagens;
    } 

    public void setQtdeFuncionarios(Integer qtdeFuncionarios) {
    	this.qtdeFuncionarios = qtdeFuncionarios;
    }
    
    public void setOnibus(Onibus onibus) {
    	this.onibus = onibus;
    }
    
    public void setBarco(Barco barco) {
    	this.barco = barco;
    }
}