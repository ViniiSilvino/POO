/*
Exercicio 1
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio1;

public class Onibus extends Veiculo
{
	protected Integer qtdePassageiros;
	protected String tipo;
	
	public Integer getQtdePassageiros() {
		return qtdePassageiros;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setQtdePassageiros(Integer qtdePassageiros) {
		this.qtdePassageiros = qtdePassageiros;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}	