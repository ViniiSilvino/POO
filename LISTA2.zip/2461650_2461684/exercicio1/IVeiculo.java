/*
Exercicio 1
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio1;

public interface IVeiculo {
	public abstract void emitirPassagem();
	public abstract void calcularPagamento();
	public abstract void calcularTempoViagem();
}