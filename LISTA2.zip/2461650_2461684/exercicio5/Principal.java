/*
Exercicio 5
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio5;

import java.util.ArrayList;

public interface IVeiculo 
{
	public void emitirPassagem();
	public void calcularPagamento(double distancia);
	public void calcularTempoViagem(double x1, double y1, double x2, double y2);	
}

public abstract class Veiculo implements IVeiculo 
{	
	private String nome;
	
	public Veiculo() {
	}

	public abstract void mostraGasolina(int gasolina); 
	public abstract void mostraMarca(String marca); 	
	public abstract void mostraVelocidade(int velocidade) ;
	public abstract void mostraAgua(int agua);
	public abstract void calibragem(int pneu);

	
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public void emitirPassagem() {
		}

		public void calcularPagamento(double distancia) {			
		}

		public void calcularTempoViagem(double x1, double x2, double y1, double y2) {
		}
}

public class Barco extends Veiculo{
	protected Integer qtdeCadeiras;
	protected Integer qtdeMesas;
	public double taxa;
	public double pagamento;
	public double distancia;
	public double tempoViagem;
	public int gasolina;
	public String marca;
	public int velocidade;
	public int agua;
	public int pneu;
	
	public Barco() {	
	}
	
	public void emitirPassagem()
	{
		taxa = 2000;
	}
	
	public void calcularPagamento(double distancia)
	{
		pagamento = 200*distancia + taxa;
	}
	
	public void calcularTempoViagem(double x1, double y1, double x2, double y2)
	{
		distancia = Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));	//raiz((x1-x2)² + (y1-y2)²)
		tempoViagem = 20*distancia;
	}
	
	public void mostraGasolina(int gasolina) 
	{
		this.gasolina = gasolina;
	}
	
	public void mostraMarca(String marca) 
	{
		this.marca = marca;
	}
	
	public void mostraVelocidade(int velocidade) 
	{
		this.velocidade = velocidade;
	}
	
	public void mostraAgua(int agua)
	{
		this.agua = agua;
	}
	
	public void calibragem(int pneu)
	{
		this.pneu = pneu;
	}
	
	public Integer getQtdeCadeiras() 
	{
		return qtdeCadeiras;
	}

	public void setQtdeCadeiras(Integer qtdeCadeiras) 
	{
		this.qtdeCadeiras = qtdeCadeiras;
	}

	public Integer getQtdeMesas() 
	{
		return qtdeMesas;
	}

	public void setQtdeMesas(Integer qtdeMesas) 
	{
		this.qtdeMesas = qtdeMesas;
	}	
}

public class Onibus extends Veiculo
{	
	private Integer qtdePassageiros;
	private String tipo;
	public double taxa;
	public double pagamento;
	public double distancia;
	public double tempoViagem;
	public int gasolina;
	public String marca;
	public int velocidade;
	public int agua;
	public int pneu;
	
	public Onibus() {
	}
	
	public void emitirPassagem()
	{
		taxa = 5;
	}
	
	public void calcularPagamento(double distancia)
	{
		pagamento= 50*distancia + taxa;
	}
	
	public void calcularTempoViagem(double x1, double y1, double x2, double y2)
	{
		distancia = Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));	//raiz((x1-x2)² + (y1-y2)²)
		tempoViagem = 50*distancia;
	}
	
	public void mostraGasolina(int gasolina) 
	{
		this.gasolina = gasolina;
	}
	
	public void mostraMarca(String marca) 
	{
		this.marca = marca;
	}
	
	public void mostraVelocidade(int velocidade) 
	{
		this.velocidade = velocidade;
	}
	
	public void mostraAgua(int agua)
	{
		this.agua = agua;
	}
	
	public void calibragem(int pneu)
	{
		this.pneu = pneu;
	}
	public Integer getQtdePassageiros() 
	{
		return qtdePassageiros;
	}

	public void setQtdePassageiros(Integer qtdePassageiros) 
	{
		this.qtdePassageiros = qtdePassageiros;
	}

	public String getTipo() 
	{
		return tipo;
	}

	public void setTipo(String tipo) 
	{
		this.tipo = tipo;
	}
}

public class EmpresaViagem 
{
    private String nome;
    private String proprietario;
    private String endereco;
    private float vendasMensais;
    private int qtdeMaxPassagens;
	private Integer qtdeFuncionarios;
    private Onibus onibus = new Onibus();
    private Barco barco = new Barco();

    public EmpresaViagem() {
    }
    
    //getters
    public String getNome() {
    	return nome;
    }
    
    public String getProprietario() {
    	return proprietario;
    }
    public String getEndereco() {
    	return endereco;
    }
    
    public Float getVendasMensais() {
    	return vendasMensais;
    }
    
    public Integer getQtdeMaxPassagens() {
    	return qtdeMaxPassagens;
    } 

    public Integer getQtdeFuncionarios() {
    	return qtdeFuncionarios;
    }
    
    public Onibus getOnibus() {
    	return onibus;
    }
    
    public Barco getBarco() {
    	return barco;
    }
    
    //setters
    public void setNome(String nome) {
    	this.nome = nome;
    }
    
    public void setProprietario(String proprietario) {
    	this.proprietario = proprietario;
    }
    public void setEndereco(String endereco	) {
    	this.endereco = endereco;
    }
    
    public void setVendasMensais(Float vendasMensais) {
    	this.vendasMensais = vendasMensais;
    }
    
    public void setQtdeMaxPassagens(Integer qtdeMaxPassagens) {
    	this.qtdeMaxPassagens = qtdeMaxPassagens;
    } 

    public void setQtdeFuncionarios(Integer qtdeFuncionarios) {
    	this.qtdeFuncionarios = qtdeFuncionarios;
    }
    
    public void setOnibus(Onibus onibus) {
    	this.onibus = onibus;
    }
    
    public void setBarco(Barco barco) {
    	this.barco = barco;
    }
}

public interface IMoeda 
{
	public abstract void convertePreco(int moeda);
}

public class Real implements IMoeda
{
	float valor;
	
	public void convertePreco(int real) 
	{
		valor = real;
	}
}

public class Bitcoin implements IMoeda 
{
	float valor;

	public void convertePreco(int real) 
	{
		valor=real/143230;
	}
}

public class Euro implements IMoeda
{
	float valor;

	public void convertePreco(int real) 
	{
		valor=real/5;
	}
}

public class Principal 
{	
	EmpresaViagem empresaViagem = new EmpresaViagem();	
	
	public Principal() 
	{	
		ArrayList<Veiculo> lista = new ArrayList<Veiculo>();
		ArrayList<IMoeda> moeda = new ArrayList<IMoeda>();
		
		Euro euro=new Euro();
		Real real = new Real();
		Bitcoin bitcoin = new Bitcoin();
		
		moeda.add(real);
		moeda.add(bitcoin);
		moeda.add(euro);
		
		euro=(Euro)moeda.get(0);
		real=(Real)moeda.get(1);
		bitcoin=(Bitcoin)moeda.get(2);
		
		Barco barco=new Barco();
		barco.setQtdeCadeiras(30);
		barco.setQtdeMesas(6);
		
		
		Onibus onibus=new Onibus();
		onibus.setQtdePassageiros(40);
		onibus.setTipo("Circular");

		lista.add(barco);
		barco=(Barco)lista.get(0);

		lista.add(onibus);
		onibus=(Onibus)lista.get(1);
		
        System.out.println("Barco:");
		System.out.println("Cadeiras: " + barco.getQtdeCadeiras());
		System.out.println("Mesas: " + barco.getQtdeMesas());
        
		System.out.println("Onibus:");		
		System.out.println("Passageiros: " + onibus.getQtdePassageiros());
		System.out.println("Tipo de Onibus: " + onibus.getTipo());
		
		barco.emitirPassagem();
		barco.calcularPagamento(20);
		barco.calcularTempoViagem(1,4,2,3);
		
		System.out.println("Taxa para o barco: " + barco.taxa);
		System.out.println("Preço total da passagem: " + barco.pagamento);
		System.out.println("Tempo de viagem de barco: " + barco.tempoViagem);

		onibus.emitirPassagem();
		onibus.calcularPagamento(40);
		onibus.calcularTempoViagem(1,8,2,8);
	
		System.out.println("Taxa para o onibus: " + onibus.taxa);
		System.out.println("Preço total da passagem: " + onibus.pagamento);
		System.out.println("Tempo de viagem de onibus: " + onibus.tempoViagem);
	
		barco.mostraGasolina(45); 
		barco.mostraMarca("levefort"); 	
		barco.mostraVelocidade(150) ;
		barco.mostraAgua(12);
		barco.calibragem(26);
		
		System.out.println("A quantidade de combustivel em L: " + barco.gasolina);
		System.out.println("A marca do barco: " + barco.marca);
		System.out.println("A velocidade maxima do barco: " + barco.velocidade);
		System.out.println("A quantidade de agua no reservatorio: " + barco.agua);
		System.out.println("A calibragem do pneu de apoio: " + barco.pneu);
	
		onibus.mostraGasolina(29); 
		onibus.mostraMarca("jeep"); 	
		onibus.mostraVelocidade(130) ;
		onibus.mostraAgua(8);
		onibus.calibragem(32);
		
		System.out.println("A quantidade de combustivel em L: " + onibus.gasolina);
		System.out.println("A marca do barco: " + onibus.marca);
		System.out.println("A velocidade maxima do barco: " + onibus.velocidade);
		System.out.println("A quantidade de agua no reservatorio: " + onibus.agua);
		System.out.println("A quantidade da pressao do pneu: " + onibus.pneu);	
		
		real.convertePreco(5000);
		bitcoin.convertePreco(5000);
		euro.convertePreco(5000);
		
		System.out.println("Valor em Real: " + real.valor);
		System.out.println("Valor em BitCoin: " + bitcoin.valor);	
		System.out.println("Valor em Euro: " + euro.valor);
	}
	
	public static void main(String []args) {
		new Principal();
	}
}
