/*
Exercicio 8
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio8;

class ExceptionC extends ExceptionB {
    public ExceptionC(String message) {
        super(message);
    }
}