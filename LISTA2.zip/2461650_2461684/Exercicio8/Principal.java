/*
Exercicio 8
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio8;

public class Principal {
    public static void main(String[] args) {
        try {
            throw new ExceptionB("Excecao: ExceptionB");
        } catch (ExceptionA exception) {
            System.out.println("Capturada ExceptionA: " + exception.getMessage());
        }

        try {
            throw new ExceptionC("Excecao: ExceptionC");
        } catch (ExceptionA exception) {
            System.out.println("Capturada ExceptionA: " + exception.getMessage());
        }
    }
}
