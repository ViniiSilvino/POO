/*
Exercicio 8
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio8;

class ExceptionA extends Exception {
    public ExceptionA(String message) {
        super(message);
    }
}
