/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

public abstract class Veiculo implements IVeiculo 
{	
	private String nome;
	
	public Veiculo() {
	}

	public abstract void mostraGasolina(int gasolina); 
	public abstract void mostraMarca(String marca); 	
	public abstract void mostraVelocidade(int velocidade) ;
	public abstract void mostraAgua(int agua);
	public abstract void calibragem(int pneu);

	
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public void emitirPassagem() {
		}

		public void calcularPagamento(double distancia) {			
		}

		public void calcularTempoViagem(double x1, double x2, double y1, double y2) {
		}
}