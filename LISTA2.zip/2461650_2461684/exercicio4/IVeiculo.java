/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

public interface IVeiculo 
{
	public void emitirPassagem();
	public void calcularPagamento(double distancia);
	public void calcularTempoViagem(double x1, double y1, double x2, double y2);	
}