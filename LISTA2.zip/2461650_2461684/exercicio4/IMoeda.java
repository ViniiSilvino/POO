/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

public interface IMoeda 
{
	public abstract void convertePreco(int moeda);
}