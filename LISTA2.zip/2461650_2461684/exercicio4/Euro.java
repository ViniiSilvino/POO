/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

public class Euro implements IMoeda
{
	float valor;

	public void convertePreco(int real) 
	{
		valor=real/5;
	}
}