/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

public class Onibus extends Veiculo
{	
	private Integer qtdePassageiros;
	private String tipo;
	public double taxa;
	public double pagamento;
	public double distancia;
	public double tempoViagem;
	public int gasolina;
	public String marca;
	public int velocidade;
	public int agua;
	public int pneu;
	
	public Onibus() {
	}
	
	public void emitirPassagem()
	{
		taxa = 5;
	}
	
	public void calcularPagamento(double distancia)
	{
		pagamento= 50*distancia + taxa;
	}
	
	public void calcularTempoViagem(double x1, double y1, double x2, double y2)
	{
		distancia = Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));	//raiz((x1-x2)² + (y1-y2)²)
		tempoViagem = 50*distancia;
	}
	
	public void mostraGasolina(int gasolina) 
	{
		this.gasolina = gasolina;
	}
	
	public void mostraMarca(String marca) 
	{
		this.marca = marca;
	}
	
	public void mostraVelocidade(int velocidade) 
	{
		this.velocidade = velocidade;
	}
	
	public void mostraAgua(int agua)
	{
		this.agua = agua;
	}
	
	public void calibragem(int pneu)
	{
		this.pneu = pneu;
	}
	public Integer getQtdePassageiros() 
	{
		return qtdePassageiros;
	}

	public void setQtdePassageiros(Integer qtdePassageiros) 
	{
		this.qtdePassageiros = qtdePassageiros;
	}

	public String getTipo() 
	{
		return tipo;
	}

	public void setTipo(String tipo) 
	{
		this.tipo = tipo;
	}
}