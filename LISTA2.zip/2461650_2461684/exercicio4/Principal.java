/*
Exercicio 4
Autor(es): Vinicius Silvino e Rafael Ribas
Data: 18/10
*/
package exercicio4;

import java.util.ArrayList;

public class Principal 
{	
	EmpresaViagem empresaViagem = new EmpresaViagem();	
	
	public Principal() 
	{	
		ArrayList<Veiculo> lista = new ArrayList<Veiculo>();
		ArrayList<IMoeda> moeda = new ArrayList<IMoeda>();
		
		Euro euro=new Euro();
		Real real = new Real();
		Bitcoin bitcoin = new Bitcoin();
		
		moeda.add(real);
		moeda.add(bitcoin);
		moeda.add(euro);
		
		euro=(Euro)moeda.get(0);
		real=(Real)moeda.get(1);
		bitcoin=(Bitcoin)moeda.get(2);
		
		Barco barco=new Barco();
		barco.setQtdeCadeiras(30);
		barco.setQtdeMesas(6);
		
		
		Onibus onibus=new Onibus();
		onibus.setQtdePassageiros(40);
		onibus.setTipo("Circular");

		lista.add(barco);
		barco=(Barco)lista.get(0);

		lista.add(onibus);
		onibus=(Onibus)lista.get(1);
		
        System.out.println("Barco:");
		System.out.println("Cadeiras: " + barco.getQtdeCadeiras());
		System.out.println("Mesas: " + barco.getQtdeMesas());
        
		System.out.println("Onibus:");		
		System.out.println("Passageiros: " + onibus.getQtdePassageiros());
		System.out.println("Tipo de Onibus: " + onibus.getTipo());
		
		barco.emitirPassagem();
		barco.calcularPagamento(20);
		barco.calcularTempoViagem(1,4,2,3);
		
		System.out.println("Taxa para o barco: " + barco.taxa);
		System.out.println("Preço total da passagem: " + barco.pagamento);
		System.out.println("Tempo de viagem de barco: " + barco.tempoViagem);

		onibus.emitirPassagem();
		onibus.calcularPagamento(40);
		onibus.calcularTempoViagem(1,8,2,8);
	
		System.out.println("Taxa para o onibus: " + onibus.taxa);
		System.out.println("Preço total da passagem: " + onibus.pagamento);
		System.out.println("Tempo de viagem de onibus: " + onibus.tempoViagem);
	
		barco.mostraGasolina(45); 
		barco.mostraMarca("levefort"); 	
		barco.mostraVelocidade(150) ;
		barco.mostraAgua(12);
		barco.calibragem(26);
		
		System.out.println("A quantidade de combustivel em L: " + barco.gasolina);
		System.out.println("A marca do barco: " + barco.marca);
		System.out.println("A velocidade maxima do barco: " + barco.velocidade);
		System.out.println("A quantidade de agua no reservatorio: " + barco.agua);
		System.out.println("A calibragem do pneu de apoio: " + barco.pneu);
	
		onibus.mostraGasolina(29); 
		onibus.mostraMarca("jeep"); 	
		onibus.mostraVelocidade(130) ;
		onibus.mostraAgua(8);
		onibus.calibragem(32);
		
		System.out.println("A quantidade de combustivel em L: " + onibus.gasolina);
		System.out.println("A marca do barco: " + onibus.marca);
		System.out.println("A velocidade maxima do barco: " + onibus.velocidade);
		System.out.println("A quantidade de agua no reservatorio: " + onibus.agua);
		System.out.println("A quantidade da pressao do pneu: " + onibus.pneu);	
		
		real.convertePreco(5000);
		bitcoin.convertePreco(5000);
		euro.convertePreco(5000);
		
		System.out.println("Valor em Real: " + real.valor);
		System.out.println("Valor em BitCoin: " + bitcoin.valor);	
		System.out.println("Valor em Euro: " + euro.valor);
	}
	
	public static void main(String []args) {
		new Principal();
	}
}