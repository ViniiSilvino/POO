package exercicio7;

public class Principal {
    public static void main(String[] args) {
        IOperacoes[] operacoes = new IOperacoes[4];
        operacoes[0] = new Soma();
        operacoes[1] = new Subtracao();
        operacoes[2] = new Multiplicacao();
        operacoes[3] = new Divisao();

        float operando1 = 10;
        float operando2 = 5;

        for (IOperacoes operacao : operacoes) {
            operacao.setOperando1(operando1);
            operacao.setOperando2(operando2);
            System.out.println("Operacao: " + operacao.getNome());
            System.out.println("Resultado: " + operacao.getResultado());
            System.out.println("Quantidade de instqncias: " + operacao.getQuantidade());
            System.out.println("------------------------");
        }
    }
}