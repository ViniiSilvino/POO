package exercicio7;

public class Divisao implements IOperacoes {
    private float operando1;
    private float operando2;

    @Override
    public void setOperando1(float operando1) {
        this.operando1 = operando1;
    }

    @Override
    public void setOperando2(float operando2) {
        this.operando2 = operando2;
    }

    @Override
    public float getResultado() {
        if (operando2 != 0) {
            return operando1 / operando2;
        } else {
            System.out.println("Erro: divisão por zero.");
            return 0;
        }
    }

    @Override
    public String getNome() {
        return "Divisao";
    }

    @Override
    public int getQuantidade() {
        return 1;
    }
}
