package exercicio7;

public interface IOperacoes {
    void setOperando1(float operando1);
    void setOperando2(float operando2);
    float getResultado();
    String getNome();
    int getQuantidade();
}
