package exercicio7;

public class Multiplicacao implements IOperacoes {
    private float operando1;
    private float operando2;

    @Override
    public void setOperando1(float operando1) {
        this.operando1 = operando1;
    }

    @Override
    public void setOperando2(float operando2) {
        this.operando2 = operando2;
    }

    @Override
    public float getResultado() {
        return operando1 * operando2;
    }

    @Override
    public String getNome() {
        return "Multiplicacao";
    }

    @Override
    public int getQuantidade() {
        return 1;
    }
}