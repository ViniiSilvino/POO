/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

abstract class Assalariado extends Empregado {
    private float salarioSemanal;

    // Construtor
    public Assalariado(String nome, String sobrenome, float salarioBase, float salarioSemanal) {
        super(nome, sobrenome, salarioBase);
        this.salarioSemanal = salarioSemanal;
    }

    // Implementação do método ganhos para Assalariado
    @Override
    public abstract float ganhos();

    // Implementação do método imprimir para Assalariado
    @Override
    public abstract void imprimir();

	public float getSalarioSemanal() {
		return salarioSemanal;
	}

	public void setSalarioSemanal(float salarioSemanal) {
		this.salarioSemanal = salarioSemanal;
	}
    
    
}