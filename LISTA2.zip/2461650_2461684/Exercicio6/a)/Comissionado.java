/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

class Comissionado extends Empregado {
    private float comissao;

    // Construtor
    public Comissionado(String nome, String sobrenome, float salarioBase, float comissao) {
        super(nome, sobrenome, salarioBase);
        this.comissao = comissao;
    }

    // Implementação do método ganhos para Comissionado
    @Override
    public float ganhos() {
        return getSalarioBase() + getSalarioBase()*comissao;
    }

    // Implementação do método imprimir para Comissionado
    @Override
    public void imprimir() {
        System.out.println("Comissionado:");
        System.out.println("Nome: " + getNome() + " " + getSobrenome());
        System.out.println("Salario Base: " + getSalarioBase());
    }

	public float getComissao() {
		return comissao;
	}

	public void setComissao(float comissao) {
		this.comissao = comissao;
	}
    
    
}