/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

class Horista extends Empregado {
    private int horas;

    // Construtor
    public Horista(String nome, String sobrenome, float salarioBase, int horas) {
        super(nome, sobrenome, salarioBase);
        this.horas = horas;
    }

    // Implementação do método ganhos para Horista
    @Override
    public float ganhos() {
        return getSalarioBase() + getSalarioBase()/horas;
    }

    // Implementação do método imprimir para Horista
    @Override
    public void imprimir() {
        System.out.println("Horista:");
        System.out.println("Nome: " + getNome() + " " + getSobrenome());
        System.out.println("Salario Base: " + getSalarioBase());
    }
}