/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

public abstract class Empregado {
    private String nome;
    private String sobrenome;
    private float salarioBase;

    // Construtor
    public Empregado(String nome, String sobrenome, float salarioBase) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.salarioBase = salarioBase;
    }

    // Métodos abstratos ganhos e imprimir (devem ser implementados pelas subclasses)
    public abstract float ganhos();
    public abstract void imprimir();

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public float getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(float salarioBase) {
		this.salarioBase = salarioBase;
	}
    
    
}