/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

class Bonificado extends Assalariado {
    private float bonificacao;

    // Construtor
    public Bonificado(String nome, String sobrenome, float salarioBase, float salarioSemanal, float bonificacao) {
        super(nome, sobrenome, salarioBase, salarioSemanal);
        this.bonificacao = bonificacao;
    }

    // Implementação do método ganhos para Bonificado
    @Override
    public float ganhos() {
        return getSalarioSemanal() + bonificacao + getSalarioBase();
    }

    // Implementação do método imprimir para Bonificado
    @Override
    public void imprimir() {
        System.out.println("Bonificado:");
        System.out.println("Nome: " + getNome() + " " + getSobrenome());
        System.out.println("Salario Base: " + getSalarioBase());
    }
}