/*
Exercicio 6
Autor(es): Rafael Ribas e Vinicíus Silvino
Data: 17,10
*/
package exercicio6;

public class Principal {
    public static void main(String[] args) {
    	Bonificado b1 = new Bonificado("Joao","Silva", 1000.0f, 100.0f, 250.0f);
    	Comissionado c1 = new Comissionado("Maria","Soares", 1000.0f, 0.1f);
    	Horista h1 = new Horista("Jomar","Silva Soares", 1000.0f, 5);

    }
}