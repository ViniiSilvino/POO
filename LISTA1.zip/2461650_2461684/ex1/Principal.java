/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

public class Principal {
	
	public Principal(){
		EmpresaViagem empresa = new EmpresaViagem();
	}
	
	public static void main(String[] args) {
		new Principal();	
	}
}


