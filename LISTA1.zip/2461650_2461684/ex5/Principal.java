/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

import java.util.Scanner;

public class Principal {
	
	String variavel;

	public Principal(){
        Scanner scanner = new Scanner(System.in);
		EmpresaViagem empresa = new EmpresaViagem("","","",0f,0,0);
		
        System.out.println("Bem-vindo ao sistema de cadastro de Empresa de Viagem!");

        System.out.print("Digite o nome da empresa: ");
        empresa.setNome(scanner.nextLine());
        System.out.print("Digite o nome do proprietario: ");
        empresa.setProprietario(scanner.nextLine());
        System.out.print("Digite o endereco: ");
        empresa.setEndereco(scanner.nextLine());
        
        System.out.print("Digite a quantidade de funcionarios: ");
        variavel = scanner.nextLine();
        empresa.setQntFuncionarios(Integer.parseInt(variavel));
        
        System.out.print("Digite a quantidade maxima de passageiros: ");
        variavel = scanner.nextLine();
        empresa.setQntMaxPassageiros(Integer.parseInt(variavel));
        
        System.out.print("Digite a quantidade de passageiros: ");
        variavel = scanner.nextLine();
        empresa.setVendasMensais(Float.parseFloat(variavel));
		
		System.out.println("\nNome: " + empresa.getNome() +
		"\nEndereco: " + empresa.getEndereco() + 
		"\nProprietario: " + empresa.getProprietario() +
		"\nQuantidade de funcionarios: " + empresa.getQntFuncionarios() +
		"\nQuantidade maxima de passageiros: " + empresa.getQntMaxPassageiros() +
		"\nVendas mensais: " + empresa.getVendasMensais() +
		"\nTipo onibus: " + empresa.onibus.getTipo() +
		"\nQuantidade de passageiros: " + empresa.onibus.getQntPassageiros());
		
		EmpresaViagem empresa2 = new EmpresaViagem("","","",0f,0,0);
		EmpresaViagem empresa3 = new EmpresaViagem("","","",0f,0,0);
		
		printClassName(empresa2);
	}
	
	public static void printClassName(Object obj) {
		Class<?> clazz = obj.getClass();
		String className = clazz.getName();
		System.out.println("Nome da classe do objeto: " + className);
	}
	
	public static void main(String[] args) {
		new Principal();	
	}
}


