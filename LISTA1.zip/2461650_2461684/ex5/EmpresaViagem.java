/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

public class EmpresaViagem {
	private String nome;
	private String proprietario;
	private String endereco;
	private Float vendasMensais;
	private Integer qntMaxPassageiros;
	private Integer qntFuncionarios;
	Onibus onibus = new Onibus();
	Onibus onibus1 = new Onibus();

	public EmpresaViagem(String nome, String proprietario,String endereco,Float vendasMensais,
			Integer qntMaxPassageiros, Integer qntFuncionarios) {
		
		this.nome = nome;
		this.proprietario = proprietario;
		this.endereco = endereco;
		this.vendasMensais = vendasMensais;
		this.qntMaxPassageiros = qntMaxPassageiros;
		this.qntFuncionarios = qntFuncionarios;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public void setVendasMensais(Float vendasMensais) {
		this.vendasMensais = vendasMensais;
	}
	public void setQntMaxPassageiros(Integer qntMaxPassageiros) {
		this.qntMaxPassageiros = qntMaxPassageiros;
	}
	public void setQntFuncionarios(Integer qntFuncionarios) {
		this.qntFuncionarios = qntFuncionarios;
	}
	
	public String getProprietario() {
		return this.proprietario;
	}
	public String getNome() {
		return this.nome;
	}
	public String getEndereco() {
		return this.endereco;
	}	
	public Float getVendasMensais() {
		return this.vendasMensais;
	}
	public Integer getQntMaxPassageiros() {
		return this.qntMaxPassageiros;
	}
	public Integer getQntFuncionarios() {
		return this.qntFuncionarios;
	}	
}


