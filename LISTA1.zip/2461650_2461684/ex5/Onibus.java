/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

public class Onibus {
	private String tipo;
	private Integer qntPassageiros;

	public Onibus(){
		this.tipo = ("");
		this.qntPassageiros = 0;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public void setQntPassageiros(Integer qntPassageiros) {
		this.qntPassageiros = qntPassageiros;
	}
	
	public String getTipo() {
		return this.tipo;
	}
	public Integer getQntPassageiros() {
		return this.qntPassageiros;
	}
}

