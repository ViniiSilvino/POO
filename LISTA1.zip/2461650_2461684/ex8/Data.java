package src;

public class Data {
	 private int dia;
	    private int mes;
	    private int ano;

	    public Data() {
	    }

	    public Data(int dia, int mes, int ano) {
	        this.dia = dia;
	        this.mes = mes;
	        this.ano = ano;
	    }

	    public String paraString() {
	        return dia+"/"+mes +"/"+ano;
	    }
}
