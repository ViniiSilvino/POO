/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

public class Principal {
	
	public Principal(){
		EmpresaViagem empresa = new EmpresaViagem();
		
		
		empresa.setNome("Garcia");
		empresa.setEndereco("Av.pirapo");
		empresa.setProprietario("Carlin");
		empresa.setQntFuncionarios(2);
		empresa.setQntMaxPassageiros(30);
		empresa.setVendasMensais(100f);
		empresa.onibus.setTipo("Mercedes");
		empresa.onibus.setQntPassageiros(10);
		
		System.out.println("Nome: " + empresa.getNome() +
		"\nEndereco: " + empresa.getEndereco() + 
		"\nProprietario: " + empresa.getProprietario() +
		"\nQuantidade de funcionarios: " + empresa.getQntFuncionarios() +
		"\nQuantidade maxima de passageiros: " + empresa.getQntMaxPassageiros() +
		"\nVendas mensais: " + empresa.getVendasMensais() +
		"\nTipo onibus: " + empresa.onibus.getTipo() +
		"\nQuantidade de passageiros: " + empresa.onibus.getQntPassageiros());
		
		EmpresaViagem empresa2 = new EmpresaViagem();
		EmpresaViagem empresa3 = new EmpresaViagem();
		
		printClassName(empresa2);
	}
	
	public static void printClassName(Object obj) {
		Class<?> clazz = obj.getClass();
		String className = clazz.getName();
		System.out.println("Nome da classe do objeto: " + className);
	}
	
	public static void main(String[] args) {
		new Principal();	
	}
}


