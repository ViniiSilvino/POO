package src;

import java.util.Random;

public class Descobrir {
	
    public static int numeroAleatorio(int inferior, int superior) {
        Random random = new Random();
        return random.nextInt(superior - inferior + 1) + inferior;
    }


}
