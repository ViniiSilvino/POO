package src;

public class EstacionamentoClientes {

	String tipoVeiculo;
	String placa;
	String horarioSaida;
	String horarioEntrada;
	Float valor;
	
	public EstacionamentoClientes(String tipoVeiculo, String placa, String horarioSaida,
									String horarioEntrada, Float valor) {
		this.tipoVeiculo = tipoVeiculo;
		this.placa = placa;
		this.horarioEntrada = horarioEntrada;
		this.horarioSaida = horarioSaida;
		this.valor = valor;
	}
	
	
	public void setTipoVeiculo(String tipoVeiculo) {
		this.tipoVeiculo = tipoVeiculo;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public void setHorarioEntrada(String horarioEntrada) {
		this.horarioEntrada = horarioEntrada;
	}
	public void setHorarioSaida(String horarioSaida) {
		this.horarioSaida = horarioSaida;
	}
	public void setValor(Float valor) {
		this.valor = valor;
	}
	
	
	public String getTipoVeiculo() {
		return this.tipoVeiculo;
	}
	public String getPlacas() {
		return this.placa;
	}
	public String getHorarioEntrada() {
		return this.horarioEntrada;
	}
	public String getHorarioSaida() {
		return this.horarioSaida;
	}
	public Float getValor() {
		return this.valor;
	}
}
