/*
Exercicio 1
Autor(es): Rafael Ribas de Lima e <NOME_DO/A_COLEGA>
Data: 05/09/2023
*/

package src;

import java.util.Scanner;
import java.time.LocalTime;
import java.time.Duration;

public class Principal {
	
	String variavel;

	public Principal(){
		
        Scanner scanner = new Scanner(System.in);
		EmpresaViagem empresa = new EmpresaViagem("","","",0f,0,0);
		
        System.out.println("Bem-vindo ao sistema de cadastro de Empresa de Viagem!");

        System.out.print("Digite o nome da empresa: ");
        empresa.setNome(scanner.nextLine());
        
        System.out.print("Digite o nome do proprietario: ");
        empresa.setProprietario(scanner.nextLine());
        
        System.out.print("Digite o endereco: ");
        empresa.setEndereco(scanner.nextLine());
        
        System.out.print("Digite a quantidade de funcionarios: ");
        variavel = scanner.nextLine();
        empresa.setQntFuncionarios(Integer.parseInt(variavel));
        
        System.out.print("Digite a quantidade maxima de passageiros: ");
        variavel = scanner.nextLine();
        empresa.setQntMaxPassageiros(Integer.parseInt(variavel));
        
        System.out.print("Digite a quantidade de vendas mensais: ");
        variavel = scanner.nextLine();
        empresa.setVendasMensais(Float.parseFloat(variavel));
		
        System.out.print("Digite o tipo do onibus: ");
        empresa.onibus.setTipo(scanner.nextLine());
        
        System.out.print("Digite a quantidade de passageiros: ");
        variavel = scanner.nextLine();
        empresa.onibus.setQntPassageiros(Integer.parseInt(variavel));
        
		System.out.println("\nNome: " + empresa.getNome() +
		"\nEndereco: " + empresa.getEndereco() + 
		"\nProprietario: " + empresa.getProprietario() +
		"\nQuantidade de funcionarios: " + empresa.getQntFuncionarios() +
		"\nQuantidade maxima de passageiros: " + empresa.getQntMaxPassageiros() +
		"\nVendas mensais: " + empresa.getVendasMensais() +
		"\nTipo onibus: " + empresa.onibus.getTipo() +
		"\nQuantidade de passageiros: " + empresa.onibus.getQntPassageiros());
		
		EmpresaViagem empresa2 = new EmpresaViagem("","","",0f,0,0);
		EmpresaViagem empresa3 = new EmpresaViagem("","","",0f,0,0);
		
		printClassName(empresa2);
		
		EstacionamentoClientes estacionamento = new EstacionamentoClientes("","","","",0f);
		
        System.out.println("\nBem-vindo ao sistema de cadastro do estacionamento!");
		
        System.out.print("Digite o tipo do veiculo: ");
        estacionamento.setTipoVeiculo(scanner.nextLine());
        
        System.out.print("Digite a placa do veiculo: ");
        estacionamento.setPlaca(scanner.nextLine());
        
        System.out.print("Digite o horario de entrada: ");
        estacionamento.setHorarioEntrada(scanner.nextLine());
        
        System.out.print("Digite o horario de saida: ");
        estacionamento.setHorarioSaida(scanner.nextLine());
        
        int diferencaMinutos = calcularDiferencaEmMinutos(estacionamento.getHorarioEntrada(), estacionamento.getHorarioSaida());
        
        if(diferencaMinutos <= 30) {
        	System.out.println("Estacionamento gratuito");
        	estacionamento.setValor(0.0f);
        } else if(diferencaMinutos <= 60) {
        	System.out.println("valor a ser pago e 10 reais");
        	estacionamento.setValor(10.0f);
        } else if(diferencaMinutos > 60) {
        	System.out.println("valor a ser pago e 20 reais");
        	estacionamento.setValor(20.0f);
        }
        
	}
	
	 public static int calcularDiferencaEmMinutos(String horarioEntrada, String horarioSaida) {
	        LocalTime entrada = LocalTime.parse(horarioEntrada);
	        LocalTime saida = LocalTime.parse(horarioSaida);

	        Duration diferenca = Duration.between(entrada, saida);

	        return (int) diferenca.toMinutes();
	    }
	
	public static void printClassName(Object obj) {
		Class<?> clazz = obj.getClass();
		String className = clazz.getName();
		System.out.println("Nome da classe do objeto: " + className);
	}
	
	public static void main(String[] args) {
		new Principal();	
	}
}


